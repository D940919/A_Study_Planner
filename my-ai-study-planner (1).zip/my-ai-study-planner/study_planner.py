"""My AI Study Planner - a beginner-friendly Python project."""

print("=== My AI Study Planner ===")

name = input("Enter your name: ").strip()
while not name:
    name = input("Please enter your name: ").strip()

goal = input("What is your AI learning goal? ").strip()
while not goal:
    goal = input("Please enter an AI learning goal: ").strip()

while True:
    try:
        days = int(input("How many days per week will you study (1-7)? "))
        if 1 <= days <= 7:
            break
        print("Please enter a number from 1 to 7.")
    except ValueError:
        print("Please enter a whole number.")

while True:
    try:
        hours = float(input("How many hours will you study each day? "))
        if 0 < hours <= 24:
            break
        print("Please enter a number greater than 0 and at most 24.")
    except ValueError:
        print("Please enter a valid number (for example, 1.5).")

weekly_hours = days * hours

plan = (
    "=== MY AI STUDY PLAN ===\n"
    f"Student: {name}\n"
    f"AI learning goal: {goal}\n"
    f"Study days per week: {days}\n"
    f"Study hours per day: {hours:g}\n"
    f"Total weekly study hours: {weekly_hours:g}\n\n"
    "Suggested daily routine:\n"
    "- First 25%: Learn a new concept.\n"
    "- Next 50%: Practice with Python or a mini-project.\n"
    "- Last 25%: Review notes and write what you learned.\n\n"
    "Weekly study schedule:\n"
)

for day in range(1, days + 1):
    plan += f"Day {day}: Study {hours:g} hour(s) toward '{goal}'.\n"

plan += "\nTip: Keep practicing and track your progress every week!\n"

print("\n" + plan)

with open("study_plan.txt", "w", encoding="utf-8") as file:
    file.write(plan)

print("Your plan has been saved to study_plan.txt")
