# My AI Study Planner

A beginner-friendly command-line Python project that creates a personalized AI learning study plan. It uses **basic Python only**—no API, GUI, database, or external libraries.

## Features

- Asks for the student's name and AI learning goal.
- Asks for study days per week and hours per day.
- Calculates total weekly study hours.
- Displays a personalized daily routine and weekly study schedule.
- Saves the generated plan as `study_plan.txt`.
- Checks that entered study days and hours are valid.

## Requirements

- Python 3 (no additional packages needed)

## How to run

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python study_planner.py
   ```

   On some computers, use `python3 study_planner.py` instead.
4. Answer the four prompts. Your plan will appear in the terminal and be saved as `study_plan.txt` in the same folder.

## Example

```text
=== My AI Study Planner ===
Enter your name: Sara
What is your AI learning goal? Learn Python for AI
How many days per week will you study (1-7)? 5
How many hours will you study each day? 2

=== MY AI STUDY PLAN ===
Student: Sara
AI learning goal: Learn Python for AI
Study days per week: 5
Study hours per day: 2
Total weekly study hours: 10

Suggested daily routine:
- First 25%: Learn a new concept.
- Next 50%: Practice with Python or a mini-project.
- Last 25%: Review notes and write what you learned.

Weekly study schedule:
Day 1: Study 2 hour(s) toward 'Learn Python for AI'.
Day 2: Study 2 hour(s) toward 'Learn Python for AI'.
Day 3: Study 2 hour(s) toward 'Learn Python for AI'.
Day 4: Study 2 hour(s) toward 'Learn Python for AI'.
Day 5: Study 2 hour(s) toward 'Learn Python for AI'.

Tip: Keep practicing and track your progress every week!
```

## Publish on GitHub

1. Create a new public repository named `my-ai-study-planner` on GitHub. Do not initialize it with a README (this project already has one).
2. From this project folder, run:

   ```bash
   git init
   git add study_planner.py README.md
   git commit -m "Add beginner AI study planner"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/my-ai-study-planner.git
   git push -u origin main
   ```

3. Replace `YOUR_USERNAME` with your GitHub username. Authenticate with GitHub when prompted.

The generated `study_plan.txt` is personal to the student and does not need to be published.
